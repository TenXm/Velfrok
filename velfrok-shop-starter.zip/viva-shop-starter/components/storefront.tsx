'use client';

import { useMemo, useState } from "react";
import { Search, ShoppingBag, UserRound, Heart, Menu, ArrowRight, ShieldCheck, Truck, RotateCcw, LockKeyhole, Headphones, Mail, Sparkles, Star, Plus, Check, MapPin, Phone, AtSign } from "lucide-react";
import { storeConfig } from "@/config/store";

type Product = { id: number; name: string; category: string; price: number; mrp: number; emoji: string; tone: string; rating: string; };
const products: Product[] = [
  { id:1, name:"Noise Cancelling Headphones", category:"Electronics", price:6499, mrp:7999, emoji:"🎧", tone:"#e8e8e5", rating:"1,234" },
  { id:2, name:"Linen Casual Shirt", category:"Fashion", price:2499, mrp:3299, emoji:"🧥", tone:"#e3e8d9", rating:"812" },
  { id:3, name:"Minimalist Niacinamide Serum", category:"Beauty", price:899, mrp:1099, emoji:"🧴", tone:"#efe4d8", rating:"645" },
  { id:4, name:"Compact Coffee Maker", category:"Home & Living", price:3999, mrp:5699, emoji:"☕", tone:"#e6e6e2", rating:"963" },
  { id:5, name:"Urban Travel Backpack", category:"Fashion", price:2999, mrp:3799, emoji:"🎒", tone:"#dfe5d8", rating:"1,108" },
  { id:6, name:"Everyday Smart Watch", category:"Electronics", price:4999, mrp:6499, emoji:"⌚", tone:"#dce9ee", rating:"521" },
  { id:7, name:"Ceramic Planter Set", category:"Home & Living", price:1199, mrp:1499, emoji:"🪴", tone:"#e7e3d9", rating:"389" },
  { id:8, name:"Weekend Running Gear", category:"Sports", price:1799, mrp:2299, emoji:"🏃", tone:"#e1e8ef", rating:"271" },
];
const categories = [
  ["Electronics","▣","#dce8eb"],["Fashion","♧","#f4dfd8"],["Home & Living","⌂","#eee6d4"],["Beauty","♙","#f2dfe4"],
  ["Sports","◉","#dce8ed"],["Toys & Kids","✿","#f1e4da"],["Books","▤","#eadfe7"],["Pet Supplies","♧","#e0e8d8"]
];
const money = (n:number) => "₹" + n.toLocaleString("en-IN");

export default function Storefront() {
  const [query,setQuery] = useState("");
  const [category,setCategory] = useState("All Categories");
  const [cart,setCart] = useState<Record<number,number>>({});
  const [saved,setSaved] = useState<number[]>([]);
  const [notice,setNotice] = useState("");
  const visible = useMemo(()=>products.filter(p=>(category==="All Categories"||p.category===category)&&`${p.name} ${p.category}`.toLowerCase().includes(query.toLowerCase())),[query,category]);
  const count = Object.values(cart).reduce((a,b)=>a+b,0);
  const subtotal = products.reduce((sum,p)=>sum+p.price*(cart[p.id]||0),0);
  const add = (p:Product) => { setCart(c=>({...c,[p.id]:(c[p.id]||0)+1})); setNotice(`${p.name} added to your demo cart`); setTimeout(()=>setNotice(""),2200); };

  return <main>
    <div style={{background:"var(--deep)",color:"#f6f4e9"}} className="text-[11px] sm:text-xs py-2 text-center tracking-wide">✨ Free shipping on orders over ₹{storeConfig.freeShippingMinimum.toLocaleString("en-IN")} <span className="mx-3 opacity-50">|</span> ◉ 30-day easy returns <span className="mx-3 opacity-50">|</span> ♙ Secure checkout</div>
    <header className="container">
      <div className="flex items-center gap-4 py-5">
        <a href="#" className="flex items-center gap-2 shrink-0" aria-label="ViVA home">
          <span className="grid place-items-center rounded-xl border-2 p-2" style={{borderColor:"#8ba18a",color:"var(--forest)"}}><ShoppingBag size={25}/></span>
          <span><b className="text-2xl tracking-[.08em]">{storeConfig.brandName}</b><small className="block text-[9px] tracking-[.18em]">{storeConfig.tagline.toUpperCase()}</small></span>
        </a>
        <div className="hidden md:flex flex-1 items-center rounded-full bg-white border border-stone-200 px-4 py-3">
          <Search size={17} className="text-stone-500"/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search products, brands and more..." className="w-full bg-transparent outline-none px-3 text-sm"/>
        </div>
        <div className="ml-auto flex items-center gap-4 sm:gap-6">
          <button className="flex flex-col items-center text-xs" onClick={()=>setNotice("Account sign-in will be enabled in the authentication phase.")}><UserRound size={20}/><span className="mt-1">Account</span></button>
          <button className="flex flex-col items-center text-xs relative" onClick={()=>setNotice("Wishlist is a local demo only.")}><Heart size={20}/>{saved.length>0&&<i className="absolute -right-2 -top-2 rounded-full bg-rose-500 text-white not-italic text-[10px] px-1.5">{saved.length}</i>}<span className="mt-1">Wishlist</span></button>
          <button className="flex flex-col items-center text-xs relative" onClick={()=>setNotice("Cart is a demo. Checkout is not connected yet.")}><ShoppingBag size={20}/>{count>0&&<i className="absolute -right-2 -top-2 rounded-full bg-rose-500 text-white not-italic text-[10px] px-1.5">{count}</i>}<span className="mt-1">Cart</span></button>
        </div>
      </div>
      <div className="flex items-center gap-5 pb-4 border-b border-stone-200">
        <button className="rounded-full px-5 py-3 text-white text-sm flex items-center gap-2" style={{background:"var(--forest)"}}><Menu size={16}/> All Categories</button>
        <nav className="hidden sm:flex items-center gap-7 text-sm overflow-x-auto whitespace-nowrap"><a className="font-semibold border-b-2 pb-3" style={{borderColor:"var(--forest)"}} href="#">Home</a><a href="#products">Shop</a><a href="#deals">Deals</a><a href="#products">New Arrivals</a><a href="#footer">About</a><a href="#reviews">Reviews</a></nav>
      </div>
      <div className="md:hidden flex items-center mt-3 rounded-full bg-white border border-stone-200 px-4 py-3"><Search size={17}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search products and more..." className="w-full bg-transparent outline-none px-3 text-sm"/></div>
    </header>

    <section className="container mt-5">
      <div className="section-card relative min-h-[350px] md:min-h-[390px] flex items-center overflow-hidden" style={{background:"linear-gradient(105deg,#e8e5d2 0%,#e9e7d7 48%,#aab9a0 100%)"}}>
        <div className="relative z-10 p-7 sm:p-10 md:p-12 max-w-[58%] sm:max-w-[55%]">
          <span className="text-xs uppercase tracking-[.22em]">Thoughtfully picked for you</span>
          <h1 className="serif text-4xl sm:text-5xl md:text-6xl font-bold leading-[1.04] mt-4">Elevate Your<br/>Everyday</h1>
          <p className="text-sm sm:text-base mt-4 max-w-sm leading-relaxed">{storeConfig.description}</p>
          <a href="#products" className="inline-flex items-center gap-2 mt-6 rounded-full px-6 py-3 text-white text-sm" style={{background:"var(--forest)"}}>Shop Now <ArrowRight size={16}/></a>
          <div className="hidden sm:flex gap-4 md:gap-6 mt-8 text-[11px]"><span>♢ Premium Quality</span><span>◇ Great Prices</span><span>♧ Trusted by shoppers</span></div>
        </div>
        <div className="absolute right-0 top-0 h-full w-[48%] flex items-center justify-center">
          <div className="absolute text-[170px] sm:text-[230px] opacity-25 rotate-[-15deg]">🌿</div>
          <div className="relative text-[125px] sm:text-[170px] drop-shadow-xl">🧳</div>
          <div className="absolute right-4 top-4 rounded-b-xl p-3 sm:p-4 text-white text-center" style={{background:"var(--forest)"}}><small className="tracking-widest">SEASONAL</small><b className="serif block text-xl sm:text-2xl">SALE</b><small>UP TO</small><strong className="block text-2xl sm:text-3xl">40%</strong><small>OFF</small></div>
          <div className="absolute bottom-4 right-6 text-4xl sm:text-5xl">🪴</div>
        </div>
      </div>
    </section>

    <section className="container py-7">
      <div className="grid grid-cols-4 sm:grid-cols-8 gap-3 sm:gap-4">
        {categories.map(([name,icon,color])=><button key={name} onClick={()=>{setCategory(name);document.getElementById("products")?.scrollIntoView({behavior:"smooth"})}} className="flex flex-col items-center gap-2 text-center"><span className="grid place-items-center rounded-full w-14 h-14 sm:w-[68px] sm:h-[68px] border-4 border-white text-2xl shadow-sm" style={{background:color}}>{icon}</span><span className="text-[10px] sm:text-xs font-semibold">{name}</span></button>)}
      </div>
    </section>

    <section id="products" className="container rounded-2xl bg-white p-4 sm:p-5 shadow-sm border border-stone-100">
      <div className="flex items-center justify-between gap-3 mb-5"><div><h2 className="serif text-2xl font-bold">Top Picks For You ✨</h2><p className="text-xs text-stone-500 mt-1">Everyday favourites, thoughtfully selected</p></div><select value={category} onChange={e=>setCategory(e.target.value)} className="max-w-[145px] rounded-full border border-stone-200 bg-white px-3 py-2 text-xs"><option>All Categories</option>{categories.map(([n])=><option key={n}>{n}</option>)}</select></div>
      {visible.length===0?<p className="py-12 text-center text-stone-500">No products match that search. Try another keyword.</p>:<div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-3 sm:gap-4">
        {visible.map(p=><article key={p.id} className="product-card">
          <div className="product-image relative" style={{background:`linear-gradient(145deg,#fff,${p.tone})`}}><span>{p.emoji}</span><span className="absolute top-3 left-3 rounded-full bg-rose-400 text-white text-[10px] font-bold px-2 py-1">-{Math.round((p.mrp-p.price)/p.mrp*100)}%</span><button aria-label="Save to wishlist" onClick={()=>setSaved(s=>s.includes(p.id)?s.filter(id=>id!==p.id):[...s,p.id])} className="absolute top-3 right-3 rounded-full bg-white/90 p-2"><Heart size={15} fill={saved.includes(p.id)?"#e87979":"none"} color={saved.includes(p.id)?"#e87979":"#173e32"}/></button></div>
          <div className="p-3"><p className="text-[10px] uppercase tracking-wide text-stone-400">{p.category}</p><h3 className="text-xs sm:text-sm font-semibold leading-snug min-h-9 mt-1">{p.name}</h3><div className="text-amber-500 text-xs mt-2">★★★★★ <span className="text-stone-400">({p.rating})</span></div><div className="flex items-center gap-2 mt-2"><b className="text-sm">{money(p.price)}</b><del className="text-[10px] text-stone-400">{money(p.mrp)}</del></div><button onClick={()=>add(p)} className="mt-3 w-full rounded-full py-2 text-xs font-semibold text-white flex items-center justify-center gap-1" style={{background:"var(--forest)"}}><Plus size={14}/> Add to Cart</button></div>
        </article>)}
      </div>}
    </section>

    <section id="deals" className="container grid sm:grid-cols-3 gap-4 py-5">
      {[["New Arrivals","Fresh Styles Just In","👜","#e3e8d5"],["Home Refresh","Make Your Space Better","🪑","#eee3d4"],["Tech Essentials","Upgrade Your Lifestyle","⌚","#dceaf0"]].map(([tag,title,emoji,bg])=><a href="#products" key={tag} className="section-card flex items-center justify-between p-5 min-h-[130px]" style={{background:bg}}><div><small>{tag}</small><h3 className="serif text-xl font-bold leading-tight mt-1">{title}</h3><span className="inline-flex items-center gap-2 text-xs mt-3">Shop Now <ArrowRight size={14}/></span></div><span className="text-6xl">{emoji}</span></a>)}
    </section>

    <section id="reviews" className="container bg-white rounded-2xl p-5 sm:p-7 my-2 border border-stone-100">
      <div className="flex justify-between items-center gap-3 mb-5"><h2 className="serif text-2xl font-bold">Loved By Thousands ❤️</h2><span className="text-xs whitespace-nowrap">4.8/5 <span className="text-amber-400">★★★★★</span></span></div>
      <div className="grid sm:grid-cols-3 gap-4">{[["Sarah J.","“Amazing quality and fast delivery! ViVA has become my go-to store for everything.”","👩🏻"],["Michael T.","“Great prices, excellent customer service, and super easy returns. Highly recommend!”","👨🏻"],["Priya K.","“I love the variety they offer. I can find everything in one place. So convenient!”","👩🏻‍🦰"]].map(([name,quote,avatar])=><div key={name} className="rounded-xl bg-stone-50 p-4"><div className="flex gap-3 items-center"><span className="text-3xl">{avatar}</span><div><b className="text-sm">{name} <Check size={12} className="inline text-emerald-700"/></b><div className="text-amber-400 text-xs">★★★★★</div></div></div><p className="text-xs leading-relaxed mt-3 text-stone-600">{quote}</p><small className="text-[9px] text-stone-400">Sample design content — replace with genuine reviews.</small></div>)}</div>
    </section>

    <section className="container my-5 rounded-2xl p-6 sm:p-8 text-white flex flex-col sm:flex-row gap-5 items-center" style={{background:"var(--forest)"}}><span className="rounded-full bg-white text-forest p-4"><Mail size={30} color="#073d32"/></span><div className="flex-1 text-center sm:text-left"><h2 className="serif text-2xl">Stay in the Loop</h2><p className="text-xs text-white/75 mt-1">Get exclusive deals, new arrivals and style inspiration straight to your inbox.</p></div><form className="flex w-full sm:w-auto gap-2" onSubmit={e=>{e.preventDefault();setNotice("Newsletter signup will be connected after email service setup.")}}><input aria-label="Email address" type="email" required placeholder="Enter your email address" className="min-w-0 flex-1 sm:w-64 rounded-full px-4 py-3 text-sm text-stone-900 outline-none"/><button className="rounded-full px-5 py-3 text-sm font-semibold" style={{background:"#e5e9d4",color:"var(--forest)"}}>Subscribe</button></form></section>

    <section className="container grid grid-cols-2 sm:grid-cols-4 gap-4 py-6 border-y border-stone-200">{[[Truck,"Free Shipping","On orders over ₹999"],[RotateCcw,"Easy Returns","30-day return policy"],[LockKeyhole,"Secure Payments","Secure checkout setup"],[Headphones,"Support","We're here to help"]].map(([Icon,title,sub])=>{const I=Icon as typeof Truck;return <div key={String(title)} className="flex gap-3 items-center justify-center"><I size={25} strokeWidth={1.5}/><div><b className="block text-xs">{String(title)}</b><small className="text-[10px] text-stone-500">{String(sub)}</small></div></div>})}</section>

    <footer id="footer" className="mt-5 text-white" style={{background:"var(--deep)"}}><div className="container py-9 grid grid-cols-2 sm:grid-cols-4 gap-7"><div className="col-span-2 sm:col-span-1"><b className="text-2xl tracking-[.08em]">♧ {storeConfig.brandName}</b><small className="block tracking-[.18em] text-[9px]">{storeConfig.tagline.toUpperCase()}</small><p className="text-xs text-white/65 mt-4 leading-relaxed">Your one-stop shop for useful everyday essentials, selected to make your routine feel a little easier.</p><div className="grid gap-2 mt-4 text-[11px] text-white/70"><span className="flex gap-2 items-start"><MapPin size={13}/>{storeConfig.address}</span><span className="flex gap-2 items-start"><AtSign size={13}/>{storeConfig.contactEmail}</span><span className="flex gap-2 items-start"><Phone size={13}/>{storeConfig.contactPhone}</span></div></div><div><b className="text-sm">Shop</b><div className="grid gap-2 text-xs text-white/65 mt-4"><a href="#products">All Categories</a><a href="#products">New Arrivals</a><a href="#deals">Best Sellers</a><a href="#deals">Deals</a></div></div><div><b className="text-sm">Customer Service</b><div className="grid gap-2 text-xs text-white/65 mt-4"><a href="#footer">Track Order</a><a href="#footer">Returns & Refunds</a><a href="#footer">Shipping Info</a><a href="#footer">Contact Us</a></div></div><div><b className="text-sm">Company</b><div className="grid gap-2 text-xs text-white/65 mt-4"><a href="#footer">About Us</a><a href="#footer">Privacy Policy</a><a href="#footer">Terms of Service</a><a href="#footer">Sustainability</a></div></div></div><div className="border-t border-white/10 py-4 text-center text-[10px] text-white/60">© 2026 ViVA. All rights reserved. <span className="mx-2">•</span> Demo storefront — not yet accepting orders.</div></footer>

    <button aria-label="Open shopping cart" onClick={()=>setNotice(count>0?`Your demo cart has ${count} item(s), subtotal ${money(subtotal)}. Secure checkout is not active yet.`:"Your cart is empty. Add an item to get started.")} className="fixed bottom-4 right-4 z-40 flex items-center gap-3 rounded-full px-5 py-4 text-white shadow-xl" style={{background:"var(--forest)"}}><span className="relative"><ShoppingBag size={21}/><i className="absolute -right-2 -top-2 rounded-full bg-rose-400 text-white not-italic text-[10px] min-w-4 h-4 px-1 grid place-items-center">{count}</i></span><span className="text-left"><b className="block text-sm">{count>0?`${count} item${count===1?"":"s"} · ${money(subtotal)}`:"Your Cart"}</b><small className="text-[10px]">{count>0?"Demo cart · checkout not active":"View your shopping cart"}</small></span><ArrowRight size={18}/></button>
    {notice&&<div role="status" className="fixed top-5 left-1/2 -translate-x-1/2 z-50 max-w-[90%] rounded-full bg-stone-900 text-white px-5 py-3 text-sm shadow-xl">{notice}</div>}
  </main>;
}
