import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: { default: "Velfrok — Better living", template: "%s | Velfrok" },
  description: "Useful everyday essentials, selected to make your routine feel a little easier.",
  metadataBase: new URL(process.env.NEXT_PUBLIC_SITE_URL || "https://example.com"),
  robots: { index: true, follow: true },
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
