# Velfrok — Better living

A mobile-first storefront inspired by the supplied reference image and built around the uploaded **Online Shop Master PRD**. This starter is designed to be saved to GitHub from a phone. It is a **UI starter**, not a production commerce system yet: database, authentication, payment verification and admin authorization must be completed and tested before real orders or customer data are accepted.

## What is included
- Next.js App Router + TypeScript + Tailwind CSS foundation
- Responsive Velfrok storefront, categories, sample product cards, promo panels, testimonials and footer
- Search and category filtering for demo products
- Add-to-cart state and floating checkout prompt (demo only)
- Security headers baseline, environment variable template, SQL schema/RLS foundation
- Phase-by-phase phone-first GitHub instructions

## Important security boundary
The storefront's demo product data and cart are not connected to a backend. Do not use it to take real payments, collect addresses, or claim an order is confirmed. The PRD requires server-side price calculation, atomic inventory reservation, Supabase RLS, admin password + email OTP/MFA (`aal2`), and Upstash rate limits. These are deployment blockers, not optional polish.

## Quick start — no terminal required
1. Open GitHub in your mobile browser/app and create a repository named `viva-shop`.
2. Add files from this project one by one using **Add file → Create new file**; use the paths shown in this package. For many files, GitHub's web editor is easier in desktop mode if available.
3. Import the GitHub repository into Vercel and deploy. A deployment may fail until dependencies and configuration are set; follow the `package.json` and Vercel prompts.
4. Create a Supabase project. Run `supabase/migrations/0001_initial_schema.sql` in Supabase Dashboard → SQL Editor only after reviewing it.
5. Add the environment variables listed in `.env.example` to Vercel Project → Settings → Environment Variables. Never commit `.env.local`, API keys, service-role keys, or SMTP secrets.
6. Continue through `docs/PHONE_WORKFLOW.md`.

## Before production
- Implement and test real Supabase server queries and all RLS policies.
- Implement customer OTP auth and admin password + OTP/MFA with `aal2` verification on every admin page/action.
- Implement Upstash rate limits and Zod validation on server actions.
- Implement atomic order placement and unique 12-digit UTR validation/uniqueness.
- Configure actual merchant UPI VPA and verify payments manually or through a trusted payment provider. A UTR is not proof of payment.
- Add invoice generation, order tracking, coupons, admin modules, sitemap/robots and Google Search Console.
- Run anonymous/customer/admin security tests before launch.

## Replace demo content
Edit `config/store.ts` later to change the brand tagline, description, address, contact details and merchant UPI ID. Change currency/product copy, images and legal policies only when you have accurate business information. All prices/products currently shown are examples.
