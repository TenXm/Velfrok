-- ViVA schema foundation. Review and run in Supabase SQL Editor.
-- This is a baseline, not the entire PRD implementation. Test policies before production.
create extension if not exists pgcrypto;

create or replace function public.is_verified_admin()
returns boolean
language sql
stable
as $$
  select coalesce(
    (auth.jwt() -> 'app_metadata' ->> 'role') = 'admin'
    and (auth.jwt() ->> 'aal') = 'aal2',
    false
  );
$$;

create table if not exists public.categories (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  slug text not null unique,
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  sku text not null unique,
  slug text not null unique,
  name text not null,
  description text not null default '',
  category_id uuid references public.categories(id),
  images text[] not null default '{}',
  colours text[] not null default '{}',
  quantity integer not null default 0 check (quantity >= 0),
  dimensions text,
  weight text,
  mrp numeric(12,2) not null check (mrp > 0),
  selling_price numeric(12,2) not null check (selling_price > 0 and selling_price <= mrp),
  discount_pct integer generated always as (round(((mrp - selling_price) / mrp) * 100)::integer) stored,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.coupons (
  id uuid primary key default gen_random_uuid(),
  code text not null unique,
  discount_type text not null check (discount_type in ('percentage','flat')),
  discount_value numeric(12,2) not null check (discount_value > 0),
  min_order_value numeric(12,2) not null default 0 check (min_order_value >= 0),
  max_discount numeric(12,2),
  expires_at timestamptz,
  total_usage_limit integer,
  per_customer_limit integer,
  usage_count integer not null default 0,
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  order_code text not null unique,
  user_id uuid not null references auth.users(id) on delete restrict,
  customer_name text not null,
  mobile text not null check (mobile ~ '^[6-9][0-9]{9}$'),
  email text not null,
  street_address text not null,
  city text not null,
  state text not null,
  pin_code text not null check (pin_code ~ '^[0-9]{6}$'),
  subtotal numeric(12,2) not null check (subtotal >= 0),
  discount numeric(12,2) not null default 0 check (discount >= 0),
  total numeric(12,2) not null check (total >= 0),
  coupon_id uuid references public.coupons(id),
  utr_number text,
  payment_status text not null default 'pending_utr'
    check (payment_status in ('pending_utr','pending_verification','accepted','rejected')),
  fulfillment_status text not null default 'pending'
    check (fulfillment_status in ('pending','confirmed_packed','shipped','delivered')),
  courier text,
  tracking_url text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint utr_format check (utr_number is null or utr_number ~ '^[0-9]{12}$')
);

create unique index if not exists idx_unique_utr
  on public.orders(utr_number) where utr_number is not null;

create table if not exists public.order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete restrict,
  product_id uuid not null references public.products(id) on delete restrict,
  sku text not null,
  product_name text not null,
  selected_colour text,
  quantity integer not null check (quantity between 1 and 20),
  unit_price numeric(12,2) not null check (unit_price > 0),
  mrp_snapshot numeric(12,2) not null check (mrp_snapshot > 0),
  created_at timestamptz not null default now()
);

alter table public.categories enable row level security;
alter table public.products enable row level security;
alter table public.coupons enable row level security;
alter table public.orders enable row level security;
alter table public.order_items enable row level security;

-- Public storefront may only read active catalog entries.
create policy "Public reads active categories" on public.categories
  for select to anon, authenticated using (is_active or public.is_verified_admin());
create policy "Public reads active products" on public.products
  for select to anon, authenticated using (is_active or public.is_verified_admin());

-- Admin data changes require BOTH trusted app_metadata role and aal2.
create policy "Verified admins manage categories" on public.categories
  for all to authenticated using (public.is_verified_admin()) with check (public.is_verified_admin());
create policy "Verified admins manage products" on public.products
  for all to authenticated using (public.is_verified_admin()) with check (public.is_verified_admin());
create policy "Verified admins manage coupons" on public.coupons
  for all to authenticated using (public.is_verified_admin()) with check (public.is_verified_admin());

-- Customers can read only their own orders. Order creation/UTR edits must be via
-- carefully granted SECURITY DEFINER RPCs in a later migration, not direct client writes.
create policy "Customers and admins read permitted orders" on public.orders
  for select to authenticated
  using (user_id = (select auth.uid()) or public.is_verified_admin());
create policy "Customers and admins read permitted order items" on public.order_items
  for select to authenticated using (
    public.is_verified_admin() or exists (
      select 1 from public.orders o
      where o.id = order_items.order_id and o.user_id = (select auth.uid())
    )
  );

-- No public coupon SELECT policy by design. No direct customer INSERT/UPDATE policy
-- for orders or order_items by design. Add secure RPCs only after reviewing privileges.
revoke all on public.coupons from anon, authenticated;
grant select on public.categories, public.products to anon, authenticated;
grant select on public.orders, public.order_items to authenticated;
grant all on public.categories, public.products, public.coupons, public.orders, public.order_items to service_role;

-- Next migration must add SECURITY DEFINER RPCs with explicit search_path, execute grants,
-- server-side price/coupon checks, row locks, stock reservation, and controlled UTR updates.
