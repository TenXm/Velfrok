/**
 * Velfrok business details.
 * Edit these values when your real business information is ready.
 * Keep this file limited to display/configuration data. Never put API secrets here.
 * Do not use a real UPI ID in checkout until server-side payment/order handling is implemented.
 */
export const storeConfig = {
  brandName: "Velfrok",
  tagline: "Better living",
  description: "Useful everyday essentials, selected to make your routine feel a little easier.",
  address: "Address to be added",
  contactEmail: "Contact email to be added",
  contactPhone: "Contact number to be added",
  upiId: "your-upi-id@bank",
  currency: "INR",
  freeShippingMinimum: 999,
} as const;
