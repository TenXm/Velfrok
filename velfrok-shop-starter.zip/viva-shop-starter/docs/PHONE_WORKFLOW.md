# Phone-first build guide (Android, no terminal)

This follows the PRD's order: repository → cloud services → database/RLS → authentication/security → storefront/checkout → admin → audit/deployment → Google indexing.

## Phase 1 — Create the GitHub repository
1. Open GitHub and sign in.
2. Tap **+ → New repository**. Name it `viva-shop`.
3. Choose **Private** while building. Add a README only if you want; if you do, avoid replacing this project's README accidentally.
4. In this project ZIP, open each file's path. In GitHub choose **Add file → Create new file**, enter the exact path (for example `app/page.tsx`), paste the complete file contents, and commit.
5. Repeat for each file. Create folders automatically by typing the path with `/`.
6. Upload the provided `Online Shop Master Prd.pdf` separately to a `docs/reference/` folder if you want the original PRD stored in the repo. Do not upload secrets or customer data.

## Phase 2 — Configure Supabase
1. Create a Supabase project.
2. Open **SQL Editor**, create a new query, paste `supabase/migrations/0001_initial_schema.sql`, review, then run.
3. In Storage, later create a `product-images` bucket with public read and admin-only write policies. Limit images to JPEG/PNG/WebP and 5 MB.
4. Important: schema is only the foundation. Do not accept real orders until atomic order RPCs and all tests are completed.

## Phase 3 — Authentication and secret setup
1. Configure Supabase Auth email delivery using a supported SMTP provider.
2. Store public Supabase URL/anon key in Vercel environment variables.
3. Store service-role key, SMTP/API secrets and Upstash tokens only as server-side Vercel secrets. Never paste them into frontend files, GitHub, screenshots, or chat.
4. Implement customer OTP and admin password + email OTP/MFA (`aal2`) before opening `/admin`. A hidden URL is not security.

## Phase 4 — Preview the design
1. Import the GitHub repository into Vercel.
2. Add the environment variables in Vercel project settings. The UI preview does not need the database connected yet.
3. Deploy and open the provided Vercel URL on your phone.
4. Check small screen layout, product filtering, add-to-cart counter, footer and readability. Cart and account are deliberately demo-only.

## Phase 5 — Complete checkout securely
Implement server actions with Zod validation and Upstash rate limits. Server must fetch authoritative product prices, calculate coupon and totals, reserve stock atomically, create order items with price snapshots, generate UPI URI/QR using a server-locked INR total, and reject duplicate/non-12-digit UTR values. Never trust totals sent by a browser. A UTR number is a customer-provided reference, not independent proof that money arrived.

## Phase 6 — Admin modules
After the admin `aal2` guard is verified on every route/action, implement:
1. Orders: filters, bulk operations, CSV, payment state, stock restoration on rejection, invoice barcode/QR.
2. Products: multiple images, category creation, SKU, stock, variants, dimensions, weight, MRP/selling price and automatic discount.
3. Inventory: single/bulk stock updates with database transactions.
4. Coupons: active toggle, expiry, minimum value, max cap, usage limits.
At the PRD's invoice checkpoint, pause and provide a sample invoice image/PDF so the design can match it.

## Phase 7 — Security audit, deployment and SEO
1. Test anonymous, customer A, customer B and verified admin sessions. Confirm users cannot read each other's orders, list coupons, set prices, set roles or bypass stock.
2. Add a restrictive Content Security Policy and review every response header.
3. Confirm backups, privacy policy, terms, returns/refunds, shipping and support details.
4. Implement unique product metadata, OpenGraph images, Product JSON-LD, dynamic sitemap and robots rules.
5. Connect the deployed domain to Google Search Console, verify ownership, submit the sitemap, inspect URLs and request indexing. Indexing is requested, never guaranteed.

## Please do / do not
- DO commit one complete file at a time and verify the path before saving.
- DO use private repo until you're ready to publish.
- DO use separate test data and test accounts.
- DO enable 2FA on GitHub, Supabase and Vercel accounts.
- DO rotate any secret that is accidentally exposed.
- DO NOT commit `.env.local`, service-role keys, SMTP keys, or Upstash tokens.
- DO NOT expose the admin route before `aal2` + role checks are enforced server-side.
- DO NOT accept real payments/orders in this starter.
- DO NOT treat a screenshot, front-end check, UTR or green UI badge as proof of a payment.
- DO NOT expect Google indexing immediately.
